using UnityEngine;
using MLAgents;

public class BasicAcademy : Academy
{
    public override void AcademyReset()
    {
    }

    public override void AcademyStep()
    {
    }
}
